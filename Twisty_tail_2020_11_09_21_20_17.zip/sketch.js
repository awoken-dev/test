function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220, 60, 0);

  fill(255, 80, 20)
  rect(150, 150, 100, 100)
  line(150, 150, 250, 250);
}